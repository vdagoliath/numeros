# Numeros

Es un sencillo paquete para tratar números. El paquete actualmente permite:
- Convertir un número no mayor que 3000 a número romano
- Convertir un número en su correspondiente lectura en letras. Soporta números de hasta miles de cuatrillones