# Numeros

Es un sencillo paquete para tratar números. El paquete actualmente permite:
- Convertir un número no mayor que 300 en número romano
- Convertir un número en su correspondiente lectura en letras.